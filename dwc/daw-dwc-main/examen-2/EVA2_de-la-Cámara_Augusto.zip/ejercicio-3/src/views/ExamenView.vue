<script>
export default {
  name: 'ExamenView',
  data() {
    return {
      alumnos: [],
      nuevoNombre: '',
      nuevoEmail: '',
      nuevaPassword: '',
      cambiadoNombre: false,
      cambiadoEmail: false,
      cambiadoPassword: false,
      errorNombre: false,
      errorEmail: false,
      errorPassword: false,
      campoEmail: null,
    };
  },
  mounted() {
    this.campoEmail = document.querySelector('#email');
  },
  methods: {
    agregar(e) {
      e.preventDefault();

      this.alumnos.push({ nombre: this.nuevoNombre, email: this.nuevoEmail, password: this.nuevaPassword, modoEdicion: false });

      this.nuevoNombre = '';
      this.nuevoEmail = '';
      this.nuevaPassword = '';

      this.cambiadoNombre = false;
      this.cambiadoEmail = false;
      this.cambiadoPassword = false;
    },
    borrar(index) {
      this.alumnos.splice(index, 1);
    },
    comprobarNombre() {
      this.cambiadoNombre = true;
      this.errorNombre = this.nuevoNombre === '';
    },
    comprobarEmail() {
      this.cambiadoEmail = true;
      this.errorEmail = !/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(this.nuevoEmail);

      if (this.errorEmail) this.campoEmail.focus();
    },
    comprobarPassword() {
      this.cambiadoPassword = true;
      this.errorPassword = !/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/.test(this.nuevaPassword);
    },
    setEdicion(index, estado) {
      if (estado) {
        this.editarNombre = this.alumnos[index].nombre;
        this.editarEmail = this.alumnos[index].email;
        this.editarPassword = this.alumnos[index].password;
      } else {
        if (this.editarNombre === '' || this.editarEmail === '' || this.editarPassword === '') return;

        this.alumnos[index].nombre = this.editarNombre;
        this.alumnos[index].email = this.editarEmail;
        this.alumnos[index].password = this.editarPassword;

        this.editarNombre = '';
        this.editarEmail = '';
        this.editarPassword = '';
      }

      this.alumnos[index].modoEdicion = estado;
    },
  },
  computed: {
    mostrarBtn() {
      return this.cambiadoNombre && this.cambiadoEmail && this.cambiadoPassword && !this.errorNombre && !this.errorEmail && !this.errorPassword;
    },
  },
};
</script>

<template>
  <form class="mx-auto w-25 mb-5">
    <div class="mb-3">
      <label for="nombre" class="form-label">Nombre:</label>
      <input type="text" name="nombre" id="nombre" class="form-control" v-model="nuevoNombre" @keyup="comprobarNombre" />
      <div class="form-text text-danger" v-if="errorNombre">Incorrecto</div>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email:</label>
      <input type="email" name="email" id="email" class="form-control" v-model="nuevoEmail" @blur="comprobarEmail" />
      <div class="form-text text-danger" v-if="errorEmail">Incorrecto</div>
    </div>

    <div class="mb-3">
      <label for="password" class="form-label">Password:</label>
      <input type="password" name="password" id="password" class="form-control" v-model="nuevaPassword" @keyup="comprobarPassword" />
      <div class="form-text text-danger" v-if="errorPassword">Password incorrecto</div>
    </div>

    <button type="button" class="btn btn-primary" @click="agregar" v-if="mostrarBtn">Nuevo alumno/a</button>
  </form>

  <table class="table table-striped container">
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Pasword</th>
        <th></th>
      </tr>
    </thead>

    <tbody>
      <tr v-for="(alumno, index) in alumnos" :key="index">
        <td v-if="!alumno.modoEdicion">{{ alumno.nombre }}</td>
        <td v-else>
          <input type="text" name="nombre-ed" id="nombre-ed" class="form-control" v-model="editarNombre" />
        </td>

        <td v-if="!alumno.modoEdicion">{{ alumno.email }}</td>
        <td v-else>
          <input type="email" name="email-ed" id="email-ed" class="form-control" v-model="editarEmail" />
        </td>

        <td v-if="!alumno.modoEdicion">{{ alumno.password }}</td>
        <td v-else>
          <input type="password" name="password-ed" id="password-ed" class="form-control" v-model="editarPassword" />
        </td>

        <td>
          <div class="btn-group">
            <button @click="setEdicion(index, false)" class="btn btn-primary" v-if="alumno.modoEdicion">Desactivar modo edición</button>
            <button @click="setEdicion(index, true)" class="btn btn-primary" v-else>Activar modo edición</button>
            <button @click="borrar(index)" class="btn btn-danger">Eliminar</button>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</template>
