<template>
  <div class="home">
    <img alt="Vue logo" src="/TX.jpg" />
    <HelloWorld msg="Ongi Etorri Vue.js azterketara | Bienvenido al examen de Vue.js" />
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue';

export default {
  name: 'HomeView',
  components: {
    HelloWorld,
  },
};
</script>
