<?php
// Variables
$hostDB = 'prueba.cqra8clixwqw.eu-west-3.rds.amazonaws.com';
$nombreDB = 'ejercicio_prueba';
$usuarioDB = 'admin';
$contrasenyaDB = 'EjercicioPrueba';

$hostPDO = "mysql:host=$hostDB;dbname=$nombreDB;";
$pdo = new PDO($hostPDO, $usuarioDB, $contrasenyaDB);
